"""Package installation and distribution configuration."""

import setuptools

# Read version from paranmr/__version__.py
version = {}
with open("paranmr/__version__.py", "r", encoding="utf-8") as f:
    exec(f.read(), version)

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setuptools.setup(
    name="paranmr",
    version=version["__version__"],
    author="Suturina Group",
    author_email="",
    description="A package for working with paramagnetic NMR spectra",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Mephistos-ML/paranmr",
    project_urls={
        "Source": "https://github.com/Mephistos-ML/paranmr",
        "Tracker": "https://github.com/Mephistos-ML/paranmr/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "."},
    packages=setuptools.find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "numpy",
        "scipy",
        "sympy",
        "matplotlib",
        "pandas",
        "pathos",
        "pyyaml",
        "pyyaml-include",
        "adjustText",
    ],
    extras_require={
        "dev": [
            "pytest>=8.0",
            "ruff>=0.1.0",
        ]
    },
    entry_points={
        "console_scripts": [
            "paranmr = paranmr.cli.main:interface",
            "plot_A_funcs = paranmr.tools.hfc_plot_batch:main",
            "plot_chi_funcs = paranmr.tools.susc_plot_batch:main",
            "xyz_to_chemlabel = paranmr.tools.coords.chemcraft:main",
        ]
    },
)
